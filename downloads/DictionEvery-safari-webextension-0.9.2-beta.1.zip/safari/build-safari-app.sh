#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
EXTENSION_DIR="$SCRIPT_DIR/DictionEverySafariExtension"
OUTPUT_DIR="$SCRIPT_DIR/DictionEverySafariApp"
APP_NAME="DictionEvery"
BUNDLE_ID="${DICTIONEVERY_BUNDLE_ID:-com.dictionevery.safari}"

PACKAGER="$(xcrun --find safari-web-extension-packager 2>/dev/null || true)"
if [[ -z "$PACKAGER" ]]; then
  PACKAGER="$(xcrun --find safari-web-extension-converter 2>/dev/null || true)"
fi

if [[ -z "$PACKAGER" ]]; then
  echo "Safari Web Extension Packager를 찾지 못했습니다."
  echo "Mac App Store에서 Xcode를 설치한 뒤 다시 실행해주세요."
  exit 1
fi

python3 -m json.tool "$EXTENSION_DIR/manifest.json" >/dev/null
node --check "$EXTENSION_DIR/background.js" >/dev/null
node --check "$EXTENSION_DIR/content.js" >/dev/null
node --check "$EXTENSION_DIR/popup.js" >/dev/null

"$PACKAGER" "$EXTENSION_DIR" \
  --project-location "$OUTPUT_DIR" \
  --app-name "$APP_NAME" \
  --bundle-identifier "$BUNDLE_ID" \
  --swift \
  --macos-only \
  --copy-resources \
  --no-open \
  --no-prompt \
  --force

echo "Safari 앱 프로젝트가 생성되었습니다:"
echo "$OUTPUT_DIR"
echo
echo "다음 단계:"
echo "1. $OUTPUT_DIR 안의 .xcodeproj를 Xcode로 엽니다."
echo "2. Signing & Capabilities에서 Apple Developer Team을 선택합니다."
echo "3. Run으로 Safari에서 테스트하거나 Archive로 배포 빌드를 만듭니다."
