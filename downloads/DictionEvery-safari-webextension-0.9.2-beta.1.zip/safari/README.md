# DictionEvery Safari App

이 폴더는 DictionEvery를 Safari에서 일반 앱 형태로 배포하기 위한 Safari Web Extension 입력물입니다.

## 구성

- `DictionEverySafariExtension/`: Safari Web Extension Packager가 읽는 확장 리소스 폴더
- `build-safari-app.sh`: Xcode가 설치된 Mac에서 Safari 앱 프로젝트를 생성하는 스크립트

## 앱 프로젝트 생성

Mac App Store에서 Xcode를 설치한 뒤, 이 프로젝트 루트에서 실행합니다.

```sh
bash safari/build-safari-app.sh
```

기본 번들 ID는 `com.dictionevery.safari`입니다. Apple Developer 계정에서 다른 번들 ID를 등록했다면 다음처럼 바꿀 수 있습니다.

```sh
DICTIONEVERY_BUNDLE_ID=com.example.dictionevery bash safari/build-safari-app.sh
```

생성 후 `safari/DictionEverySafariApp` 안의 Xcode 프로젝트를 열고 Signing & Capabilities에서 Apple Developer Team을 선택합니다.

## 일반 사용자 설치 방식

Safari 확장은 단독 파일로 설치되지 않고 macOS 앱 안에 포함됩니다.

- App Store 배포: Xcode에서 Archive 후 App Store Connect에 제출
- App Store 밖 배포: Developer ID로 서명하고 Apple 공증을 거친 `.dmg` 또는 `.pkg`로 배포

사용자는 앱을 설치한 뒤 Safari 설정의 확장 프로그램 화면에서 DictionEvery를 켜면 됩니다.

## 알려진 Safari 차이점

- Safari의 웹 확장 권한은 사용자가 사이트 접근 권한을 직접 허용해야 할 수 있습니다.
- Google 로그인은 Safari의 `identity` API 지원 상태에 따라 제한될 수 있습니다. 이메일 로그인, Supabase 수동 동기화, 사전 검색, 단어장, 테스트 기능은 WebExtension 리소스 기준으로 유지됩니다.
